class RemoveMeasurementsFromWeatherstations < ActiveRecord::Migration
  def change
  end
end
