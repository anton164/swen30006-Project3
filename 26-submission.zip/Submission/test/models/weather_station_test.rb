require 'test_helper'

class WeatherStationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
